import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;

import java.util.Collections;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;


public class FastCollinearPoints {
    private List<LineSegmentPenis> foundSegments = new ArrayList<>();
//    private HashMap<Double, List<LineSegmentPenis>> slopesToSegments = new HashMap<>();

    // finds all line foundSegments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        Point[] pointsCopy = Arrays.copyOf(points, points.length);
        Arrays.sort(points);
        for (Point startPoint : points) {
            Arrays.sort(pointsCopy, startPoint.slopeOrder());
            List<Point> pointsOnSlope = new ArrayList<>();
            double currentSlope = 0;
            double prevSlope = Double.NEGATIVE_INFINITY;
            for (int i = 1; i < pointsCopy.length; i++) {
                Point currentPoint = pointsCopy[i];
                currentSlope = startPoint.slopeTo(currentPoint);
                if (currentSlope == prevSlope) {
                    pointsOnSlope.add(currentPoint);
                } else {
                    if (pointsOnSlope.size() >= 3) {
                        pointsOnSlope.add(startPoint);
                        addSegmentIfNew(prevSlope, createSegment(pointsOnSlope));
                    }
                    pointsOnSlope.clear();
                    pointsOnSlope.add(currentPoint);
                }
                prevSlope = currentSlope;
            }
            if (pointsOnSlope.size() >= 3) {
                pointsOnSlope.add(startPoint);
                addSegmentIfNew(currentSlope, createSegment(pointsOnSlope));
            }
        }
    }

    private LineSegmentPenis createSegment(List<Point> points) {
        return new LineSegmentPenis(Collections.min(points), Collections.max(points));
    }

    private void addSegmentIfNew(Double slope, LineSegmentPenis segment) {
        if (!foundSegments.contains(segment)) {
            foundSegments.add(segment);
        }
//        if (!slopesToSegments.containsKey(slope)) {
//            foundSegments.add(segment);
//        } else if (!slopesToSegments.get(slope).contains(segment)) {
//            foundSegments.add(segment);
//        }
//        slopesToSegments.putIfAbsent(slope, new ArrayList<>());
//        slopesToSegments.get(slope).add(segment);
    }

    // the number of line foundSegments
    public int numberOfSegments() {
        return foundSegments.size();
    }

    // the line foundSegments
    public LineSegment[] segments() {
        LineSegment[] segments = new LineSegment[numberOfSegments()];
        for (int i = 0; i < numberOfSegments(); i++) {
            segments[i] = new LineSegment(foundSegments.get(i).p, foundSegments.get(i).q);
        }
        return segments;
    }

    public static void main(String[] args) {
        In in = new In("collinear/input8_test.txt");
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }


        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 30);
        StdDraw.setYscale(0, 30);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        FastCollinearPoints f = new FastCollinearPoints(points);
        System.out.println(f.numberOfSegments() + " foundSegments");
        for (LineSegment segment : f.segments()) {
            segment.draw();
            System.out.println(segment);
        }
        StdDraw.show();
    }

    private class LineSegmentPenis {
        private final Point p;   // one endpoint of this line segment
        private final Point q;   // the other endpoint of this line segment

        /**
         * Initializes a new line segment.
         *
         * @param  p one endpoint
         * @param  q the other endpoint
         * @throws NullPointerException if either <tt>p</tt> or <tt>q</tt>
         *         is <tt>null</tt>
         */
        LineSegmentPenis(Point p, Point q) {
            if (p == null || q == null) {
                throw new NullPointerException("argument is null");
            }
            this.p = p;
            this.q = q;
        }


        /**
         * Draws this line segment to standard draw.
         */
        public void draw() {
            p.drawTo(q);
        }

        /**
         * Returns a string representation of this line segment
         * This method is provide for debugging;
         * your program should not rely on the format of the string representation.
         *
         * @return a string representation of this line segment
         */
        public String toString() {
            return p + " -> " + q;
        }

        /**
         * Throws an exception if called. The hashCode() method is not supported because
         * hashing has not yet been introduced in this course. Moreover, hashing does not
         * typically lead to good *worst-case* performance guarantees, as required on this
         * assignment.
         *
         * @throws UnsupportedOperationException if called
         */
        public int hashCode() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) return true;
            if (other == null) return false;
            if (!(other instanceof LineSegmentPenis)) return false;
            LineSegmentPenis otherPoint = (LineSegmentPenis) other;
            return (this.p.compareTo(otherPoint.p) == 0 && this.q.compareTo(otherPoint.q) == 0) ||
                    (this.p.compareTo(otherPoint.q) == 0 && this.q.compareTo(otherPoint.p) == 0);
        }
    }
}